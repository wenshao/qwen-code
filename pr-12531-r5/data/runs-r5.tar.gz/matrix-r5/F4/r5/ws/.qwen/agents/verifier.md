---
name: verifier
description: PR12531 verification subagent
disallowedTools:
  - "mcp__foo____*"
---

SUBAGENT-PR12531 marker. Call the tool you are told to call.
