---
name: verifier
description: PR12531 verification subagent
---

SUBAGENT-PR12531 marker. Call the tool you are told to call.
