---
name: verifier
description: PR12531 verification subagent
disallowedTools:
  - "mcp__foo.bar"
---

SUBAGENT-PR12531 marker. Call the tool you are told to call.
