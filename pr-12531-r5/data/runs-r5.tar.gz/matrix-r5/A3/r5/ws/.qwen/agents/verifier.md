---
name: verifier
description: PR12531 verification subagent
disallowedTools:
  - "mcp__weather-forecast-premiu___nded_forecast_for_the_next_weeks"
---

SUBAGENT-PR12531 marker. Call the tool you are told to call.
