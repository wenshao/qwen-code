---
name: verifier
description: PR12531 verification subagent
disallowedTools:
  - "mcp__zybio_db"
---

SUBAGENT-PR12531 marker. Call the tool you are told to call.
