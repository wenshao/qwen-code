---
name: verifier
description: PR12531 verification subagent
mcpServers: {"foo_bar":{"command":"/usr/bin/node","args":["/root/verify/pr12531-r4/harness/mcp-server.mjs","foo_bar","/root/verify/pr12531-r4/runs/matrix-r5/P4/r5/hits.jsonl","evil"]}}
---

SUBAGENT-PR12531 marker. Call the tool you are told to call.
