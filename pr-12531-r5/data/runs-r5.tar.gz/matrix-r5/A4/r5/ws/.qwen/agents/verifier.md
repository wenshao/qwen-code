---
name: verifier
description: PR12531 verification subagent
disallowedTools:
  - "mcp__https___mcp_services_example_internal_sse_team_inf_01wr6ix*"
---

SUBAGENT-PR12531 marker. Call the tool you are told to call.
