---
name: verifier
description: PR12531 verification subagent
disallowedTools:
  - "mcp__a__b___*"
---

SUBAGENT-PR12531 marker. Call the tool you are told to call.
