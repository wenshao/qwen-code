import { parseConfig } from './lib/config.ts';
// TODO: graceful shutdown
export const workerConfig = parseConfig(process.env);
