import { parseConfig } from './lib/config.ts';
import { available } from './lib/stock.ts';

const cfg = parseConfig(process.env);
export function health(): string {
  return `ok port=${cfg.port} stock=${available('demo')}`;
}
