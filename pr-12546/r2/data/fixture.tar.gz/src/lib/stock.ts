export interface Item { sku: string; qty: number }

const inventory = new Map<string, Item>();

export function addItem(sku: string, qty: number): void {
  const cur = inventory.get(sku);
  inventory.set(sku, { sku, qty: (cur?.qty ?? 0) + qty });
}

export function reserve(sku: string, qty: number): boolean {
  const cur = inventory.get(sku);
  if (!cur || cur.qty < qty) return false;
  cur.qty -= qty;
  return true;
}

export function available(sku: string): number {
  return inventory.get(sku)?.qty ?? 0;
}
