export interface Config { port: number; debug: boolean }

export function parseConfig(raw: Record<string, string | undefined>): Config {
  return { port: Number(raw.PORT ?? 8080), debug: raw.DEBUG === '1' };
}
