// TODO: handle currencies other than USD
export function cents(amount: number): number {
  return Math.round(amount * 100);
}
