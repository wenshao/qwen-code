import fs from 'node:fs';
import path from 'node:path';
let bad = 0;
for (const f of fs.readdirSync('src/lib')) {
  const s = fs.readFileSync(path.join('src/lib', f), 'utf8');
  if (/\bvar\s/.test(s)) { console.error(`${f}: no var`); bad++; }
  if (/console\.log/.test(s)) { console.error(`${f}: no console.log`); bad++; }
}
if (bad) process.exit(1);
console.log('lint ok');
