# inventory-svc
Small inventory service.
