import { test } from 'node:test';
import assert from 'node:assert/strict';
import { addItem, reserve, available } from '../src/lib/stock.ts';

test('reserve decrements stock', () => {
  addItem('a', 5);
  assert.equal(reserve('a', 2), true);
  assert.equal(available('a'), 3);
});

test('reserve fails when short', () => {
  addItem('b', 1);
  assert.equal(reserve('b', 2), false);
});
