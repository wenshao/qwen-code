CREATE TABLE qwen_runtime_binding_slot (
    request_key CHAR(64) PRIMARY KEY,
    tenant_id VARCHAR(512) NOT NULL,
    workspace_id VARCHAR(512) NOT NULL,
    workspace_generation VARCHAR(512) NOT NULL,
    canonical_cwd VARCHAR(512) NOT NULL,
    capability_digest VARCHAR(512) NOT NULL,
    isolation_class VARCHAR(32) NOT NULL,
    isolation_key VARCHAR(512),
    provisioner_kind VARCHAR(128) NOT NULL,
    placement_domain VARCHAR(512) NOT NULL,
    runtime_template_digest VARCHAR(512) NOT NULL,
    last_generation BIGINT NOT NULL,
    active_binding_id VARCHAR(512),
    CONSTRAINT uq_runtime_binding_isolation UNIQUE (isolation_key)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;

CREATE TABLE qwen_runtime_binding (
    binding_id VARCHAR(512) PRIMARY KEY,
    request_key CHAR(64) NOT NULL,
    scope_key CHAR(64) NOT NULL,
    tenant_id VARCHAR(512) NOT NULL,
    workspace_id VARCHAR(512) NOT NULL,
    workspace_generation VARCHAR(512) NOT NULL,
    canonical_cwd VARCHAR(512) NOT NULL,
    capability_digest VARCHAR(512) NOT NULL,
    isolation_class VARCHAR(32) NOT NULL,
    isolation_key VARCHAR(512),
    provisioner_kind VARCHAR(128) NOT NULL,
    placement_domain VARCHAR(512) NOT NULL,
    runtime_template_digest VARCHAR(512) NOT NULL,
    runtime_generation BIGINT NOT NULL,
    binding_state VARCHAR(32) NOT NULL,
    provision_request_id VARCHAR(512),
    provision_seed_ciphertext LONGTEXT,
    credential_key_id VARCHAR(512),
    resource_handle_version INT,
    resource_handle_json LONGTEXT,
    runtime_instance_id VARCHAR(512),
    runtime_endpoint VARCHAR(2048),
    runtime_lease_id VARCHAR(512),
    runtime_epoch BIGINT,
    runtime_credential_ciphertext LONGTEXT,
    runtime_credential_key_id VARCHAR(512),
    attestation_generation BIGINT NOT NULL,
    drain_requested BOOLEAN NOT NULL,
    operation_owner VARCHAR(512),
    operation_lease_until DATETIME(6),
    operation_generation BIGINT NOT NULL,
    record_version BIGINT NOT NULL,
    last_health_at DATETIME(6),
    last_reconciled_at DATETIME(6),
    last_active_at DATETIME(6) NOT NULL,
    CONSTRAINT uq_runtime_binding_generation
        UNIQUE (request_key, runtime_generation)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX idx_runtime_binding_scope
    ON qwen_runtime_binding (scope_key, isolation_key, binding_state);

CREATE TABLE qwen_runtime_session (
    runtime_session_id VARCHAR(512) PRIMARY KEY,
    scope_key CHAR(64) NOT NULL,
    tenant_id VARCHAR(512) NOT NULL,
    workspace_id VARCHAR(512) NOT NULL,
    workspace_generation VARCHAR(512) NOT NULL,
    canonical_cwd VARCHAR(512) NOT NULL,
    capability_digest VARCHAR(512) NOT NULL,
    isolation_class VARCHAR(32) NOT NULL,
    harness_session_id VARCHAR(512) NOT NULL,
    turn_kind VARCHAR(32) NOT NULL,
    binding_id VARCHAR(512) NOT NULL,
    runtime_generation BIGINT NOT NULL,
    session_state VARCHAR(32) NOT NULL,
    record_version BIGINT NOT NULL,
    last_active_at DATETIME(6) NOT NULL
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX idx_runtime_session_scope
    ON qwen_runtime_session (scope_key);

CREATE INDEX idx_runtime_session_binding
    ON qwen_runtime_session (
        binding_id, runtime_generation, session_state
    );

CREATE TABLE qwen_tool_execution (
    execution_call_id_hash CHAR(64) NOT NULL,
    execution_call_id VARCHAR(512) PRIMARY KEY,
    idempotency_key_hash CHAR(64) NOT NULL,
    idempotency_key VARCHAR(512) NOT NULL,
    binding_id VARCHAR(512) NOT NULL,
    runtime_generation BIGINT NOT NULL,
    harness_session_id VARCHAR(512) NOT NULL,
    runtime_session_id VARCHAR(512) NOT NULL,
    runtime_session_key CHAR(64) NOT NULL,
    turn_id VARCHAR(512) NOT NULL,
    tool_call_id VARCHAR(512) NOT NULL,
    request_digest VARCHAR(512) NOT NULL,
    reference_json LONGTEXT NOT NULL,
    execution_state VARCHAR(32) NOT NULL,
    execution_status VARCHAR(32),
    result_json LONGTEXT,
    last_sequence BIGINT NOT NULL,
    cancel_requested BOOLEAN NOT NULL,
    dispatch_owner VARCHAR(512),
    dispatch_lease_until DATETIME(6),
    dispatch_generation BIGINT NOT NULL,
    record_version BIGINT NOT NULL,
    settled_at DATETIME(6),
    CONSTRAINT uq_tool_execution_call_hash
        UNIQUE (execution_call_id_hash),
    CONSTRAINT uq_tool_execution_idempotency
        UNIQUE (idempotency_key_hash)
) DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_bin;

CREATE INDEX idx_tool_execution_session
    ON qwen_tool_execution (runtime_session_key, execution_state);

CREATE INDEX idx_tool_execution_binding
    ON qwen_tool_execution (
        binding_id, runtime_generation, execution_state
    );
