-- Verification-only synthetic stand-in for an open PR that claims V66.
CREATE TABLE probe_v66_marker (id INT PRIMARY KEY);
