#!/bin/bash
# round 2 (head 2ef8fba0d2): build head2 + merge2 (head2 + main 6ececc39), then two lanes
R=/root/pr13931-rig
echo "=== $(date +%T) queue7 start"
docker start pr13931-db >/dev/null
until docker exec pr13931-db mysqladmin -uroot -phosted-fixture ping 2>/dev/null | grep -q alive; do sleep 3; done
echo "db up"
$R/run-build.sh head2 & B1=$!
$R/run-build.sh merge2 & B2=$!
wait $B1; echo "build head2 container exit=$?"
wait $B2; echo "build merge2 container exit=$?"
grep -h "exit=" $R/out/build-head2.log $R/out/build-merge2.log
$R/build-jar.sh head2 & J1=$!
$R/build-jar.sh merge2 & J2=$!
wait $J1 $J2
echo "=== $(date +%T) BUILDS-DONE"
( $R/run-it.sh head2 r1 "HostedPublicWorkspaceIT#publicShellV2DeletionTriggersCollectionWithoutRetirementSeams"
  $R/run-rig.sh l4 head2
  $R/run-rig.sh v1off head2
  $R/run-it.sh head2 full HostedPublicWorkspaceIT
  $R/unit.sh head2
  echo "=== $(date +%T) LANE-A-DONE" ) > $R/out/q7-laneA.log 2>&1 & LA=$!
( $R/run-rig.sh l4 merge2
  $R/run-it.sh merge2 r1 "HostedPublicWorkspaceIT#publicShellV2DeletionTriggersCollectionWithoutRetirementSeams"
  $R/unit.sh merge2
  echo "=== $(date +%T) LANE-B-DONE" ) > $R/out/q7-laneB.log 2>&1 & LB=$!
wait $LA $LB
echo "=== $(date +%T) QUEUE7-DONE"
