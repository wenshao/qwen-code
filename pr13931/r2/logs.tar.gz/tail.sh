#!/bin/bash
# the two main-red Node tests: merge2 (+ #13983 test-only patch; #13964 already in 6ececc39) and head2
R=/root/pr13931-rig
docker run --rm --name pr13931-tail -v $R:$R qwen-managed-e2e:u24 bash -c "
  cd $R/src-merge2 && git apply $R/up/13983.patch && echo applied-13983
  cd $R/src-merge2/packages/cli && CI=true npx vitest run src/serve/hosted-never-started-reconcile.test.ts > $R/out/tail-merge2-reconcile.log 2>&1; echo merge2+13983 reconcile exit=\$?
  cd $R/src-head2/packages/cli && CI=true npx vitest run src/serve/hosted-never-started-reconcile.test.ts > $R/out/tail-head2-reconcile.log 2>&1; echo head2 reconcile exit=\$?
  cd $R/src-merge2/packages/web-shell && CI=true npx vitest run client/build-artifact.test.ts > $R/out/tail-merge2-artifact.log 2>&1; echo merge2 artifact exit=\$?
  cd $R/src-head2/packages/web-shell && CI=true npx vitest run client/build-artifact.test.ts > $R/out/tail-head2-artifact.log 2>&1; echo head2 artifact exit=\$?
  cd $R/src-merge2 && git apply -R $R/up/13983.patch && echo reverted-13983"
for f in merge2-reconcile head2-reconcile merge2-artifact head2-artifact; do echo "-- $f"; sed "s/\x1b\[[0-9;]*m//g" $R/out/tail-$f.log | grep -a -E "Test Files|Tests  |FAIL |expected" | head -6; done
echo TAIL-DONE
