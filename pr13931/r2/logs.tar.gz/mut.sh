#!/bin/bash
# usage: mut.sh <name> <mode>  -- copy head2 sdk-java + core contracts, mutate the verifier digest selection, run unit-java.sh
#   mode revert   : never take the rp3/deferred branch (verifier compares argsDigest, as on 86f034e9)
#   mode presence : select inputDigest by field presence (the round-1 candidate shape)
R=/root/pr13931-rig; N=$1; MODE=$2; W=$R/src-$N
F=packages/sdk-java/managed-agent-server/src/main/java/com/alibaba/qwen/code/managedagent/store/WorkspaceProfileLifecycleVerifier.java
rm -rf $W; mkdir -p $W/packages/core/src/managed-runtime
cp -r $R/src-head2/packages/sdk-java $W/packages/
cp -r $R/src-head2/packages/core/src/managed-runtime/contracts $W/packages/core/src/managed-runtime/
rm -rf $W/packages/sdk-java/*/target
[ -d $R/m2-$N ] || cp -r $R/m2-head2 $R/m2-$N
OLD="        if (Integer.valueOf(3).equals(execution.getReference().get(\"runtimeProtocol\"))"
grep -qF "$OLD" $W/$F || { echo "[$N] anchor missing"; exit 2; }
case $MODE in
  revert)   sed -i "s|&& \"deferred\".equals(execution.getReference().get(\"dispatchMode\"))) {|\&\& \"__mutant_never__\".equals(execution.getReference().get(\"dispatchMode\"))) {|" $W/$F ;;
  presence) sed -i "s|        if (Integer.valueOf(3).equals(execution.getReference().get(\"runtimeProtocol\"))|        if (execution.getReference().containsKey(\"inputDigest\") \|\| Boolean.FALSE.equals(null)|; s|&& \"deferred\".equals(execution.getReference().get(\"dispatchMode\"))) {|) {|" $W/$F ;;
esac
diff <(sed -n 278,292p $R/src-head2/$F) <(sed -n 278,292p $W/$F)
$R/unit-java.sh $N
